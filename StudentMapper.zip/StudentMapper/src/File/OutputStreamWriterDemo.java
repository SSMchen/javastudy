package File;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;

public class OutputStreamWriterDemo {
    public static void main(String[] args) throws IOException {
        //OutputStreamWriter (OutputStream out):创建一个使用默认字符编码的OutputStreamWriter
        OutputStreamWriter osw = new OutputStreamWriter(new FileOutputStream("osw.txt"));
        //void write(int c)  :写一个字符
        osw.write(97);
        //字符流写数据不能直接写入文件中，最终通过字节流写
//字符输出流中的一个方法：void flush()   刷新流
        osw.flush();
        osw.write(98);
        osw.flush();
        osw.write(99);
        //String getEncoding()   返回此流使用的字符编码的名称
        System.out.println(osw.getEncoding());
        //void write(char[] cbud) 写入一个字符数组
        char[] chs = {'a','b','c','d'};
        osw.write(chs);
        //void write(char[] cbuf,int off,int len):写入字符数组的一部分
        osw.write(chs,0, chs.length);//abcd
        osw.write(chs,1,3);//bcd
        //void write(String str):写一个字符串
        osw.write("2654zvasd");
        //void write(String str,int off,int len):写一个字符串的一部分
        osw.write("6598aaav1",0,6);// 6598aa
        //void close()  关闭流，先刷新
        osw.close();
    }
}
