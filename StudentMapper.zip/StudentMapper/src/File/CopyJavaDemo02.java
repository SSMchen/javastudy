package File;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/*
需求：把模块目录下的“CoversionStreamDemo.java“复制到模块目录下的Copy.java
数据源：模块下ConversionStreamDemo.java--读数据--Reader--InputStreamReader---FileReader
目的地：模块下Copy.java---写数据---writer--OutputStreamWriter--FileWriter
思路：
1. 根据数据源创建字符输入流对象
2. 根据目的地创建字符输入流对象
3. 读写数据，复制文件
4. 释放资源
 */
public class CopyJavaDemo02 {
    public static void main(String[] args) throws IOException {
        //1.根据数据源创建字符输入流对象
        FileReader fr = new FileReader("ConversionStreamDemo.java");
        //2. 根据目的地创建字符输入流对象
        FileWriter fw = new FileWriter("Copy.java");
        //读写数据，复制文件：
        //FileReader继承自InputStreamReader所以FileReader也有两种读取数据方式
        int ch ;
        while ((ch=fr.read())!=-1){
            fw.write(ch);
        }//这样就复制完了
        char[] chs = new char[1024];
        int len;
        while ((len=fr.read(chs))!=-1){
            fw.write(chs,0,len);
        }
        //FileWriter继承自OutputStreamWriter所以FileWriter也有对应的写数据的方式

        //4. 释放资源
        fw.close();
        fr.close();
    }
}
