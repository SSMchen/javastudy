package File;

import java.io.*;

/*
字节缓冲流：
       BufferedOutputStream
       BufferedInputStream
  构造方法：
        字节缓冲输出流：BufferedOutputStream
        字节缓冲输入流：BufferedInputStream
 */
public class BufferedStreamDemo {
    public static void main(String[] args) throws IOException {
        //创建  字节缓冲输出流：BufferedOutputStream  对象
//        FileOutputStream fos = new FileOutputStream("bos.txt");
//        BufferedOutputStream bos = new BufferedOutputStream(fos);

        BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream("bos.txt"));
        //写数据
        bos.write("hello\r\n".getBytes());
        bos.write("world\r\n".getBytes());
        //释放资源
        bos.close();

        //创建 字节缓冲输入流：BufferedInputStream  对象
        BufferedInputStream bis = new BufferedInputStream(new FileInputStream("bos.txt"));
        //读数据 (1) 一次读取一个字节数据
        int by ;
        while ((by=bis.read())!=-1){
            System.out.print((char)by);
        }
        //读数据 (2) 一次读取一个字节数组数据
        byte[] bys = new byte[1024];
        int len;
        while ((len = bis.read(bys))!=-1){
            System.out.print(new String(bys,0,len));
        }
        //释放资源
        bis.close();
    }
}
