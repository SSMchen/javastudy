package File;

import java.io.File;
import java.io.IOException;

public class FileDemo {
//    public static void main(String[] args) {
//        //File(File parent, String child):
//        //  从父抽象路径名和子路径名字符串创建新的 File实例
//        File f1 = new File("E:\\java.txt");//抽象路径
//        System.out.println(f1);  //输出了路径内容所以说：file类重写的toString方法
//        //File(String pathname)：
//        // 通过将给定的路径名字符串转换为抽象路径名来创建新的 File实例
//        File f2 = new File("E:\\itcast","java.txt");
//        System.out.println(f2);
////File(String parent ,String child):
//// 从父路径名字符串和子路径名字符串创建新的 File实例。
//        File f3 = new File("E:\\incast");
//        File f4 = new File(f3,"java.txt");
//        System.out.println(f4);
//    }
public static void main(String[] args) throws IOException {
    //需求1：我要在E:\\itcast目录下创建一个文件java.txt
    File f1 = new File("E:\\itcast\\java.txt");
    System.out.println(f1.createNewFile());
    //，如果文件不存在就创建文件，并返回TRUE
    // 如果文件存在就不创建文件，并返回False‘再次创建为false
    //需求2：我要在E:\\itcast目录下创建一个文件JavaSE
    File f2 = new File("E:\\itcast\\JavaSE");
    System.out.println(f2.mkdir());

    //需求3：我要在E:\\itcast目录下创建一个文件JavaWEB\\HTML
    File f3 = new File("E:\\itcast\\JavaWEB\\html");
//    System.out.println(f3.mkdir());
    System.out.println(f3.mkdirs());
    //需求4：我要在E:\\itcast目录下创建一个文件javase.txt
    File f4 = new File("E:\\itcast\\javase.txt");
//    System.out.println(f4.mkdir());//创建了一个名为javase.txt的文件夹
    System.out.println(f4.createNewFile());
}
}
