package File;

import sun.nio.cs.ext.GBK;

import java.io.FileInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;

/*
需求：字节流读文本文件数据

一个汉字存储：
    GBK编码：占用两个字节
    UTF-8编码：占用三个字节
 */
public class FileInputStreamzifu {
    public static void main(String[] args) throws IOException {
//        FileInputStream fis = new FileInputStream("a.txt");
//        int by;
//        while ((by = fis.read())!=-1){
//            System.out.print((char)by);
//        }//ä¸­：中
//        //å½：国
//        fis.close();
//        String s = "abc";//[97, 98, 99]
        String s= "中国";//[-28, -72, -83, -27, -101, -67]
                        //      中       ,       国
        //默认平台编码是UTF-8
        byte[] bys = s.getBytes("GBK");//[-42, -48, -71, -6]
                                                   //    中   ,    国
        //汉字的第一个字节是负数，在拼接时就知道这是汉字
        System.out.println(Arrays.toString(bys));
    }
}
