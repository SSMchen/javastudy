package File;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

/*
文件输出流是用于**将数据写入File**或FileDescriptor的输出流。
    FileOutputStream(String name)：创建文件输出流以指定的名称写入文件
 */
public class FileOutputStreamDemo {
    public static void main(String[] args) throws IOException {//FileNotFoundException是IOException异常的字异常
        //创建字节输出流对象
        //FileOutputStream(String name)：创建文件输出流以指定的名称写入文件
        FileOutputStream fos = new FileOutputStream("fos.txt");
        /*
        FileOutputStream
        做了三件事情：
            A：调用系统功能创建了文件
            B：创建了字节输出流对象
            C：让字节输出流对象指向创建好的文件
            fos 指向fos.txt
         */
        //void  write(int b) :将指定的字节写入此文件输出流
        fos.write(97);//a
//        记事本打开时转换了转换成立字符
//        fos.write(57);//9
//        fos.write(55);//7
        //所有和IO相关操作，最后都要释放资源
//void  close()：关闭此文件输出流并释放与此流相关联的任何系统资源
        /*
        close做了两件事：
            A：关闭此文件输出流
            B：释放与此流相关联的任何系统资源
         */
        fos.close();

    }
}
