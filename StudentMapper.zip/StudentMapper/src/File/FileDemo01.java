package File;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

/*
public boolean isDirectory()    | 测试此抽象路径名表示的File是否为目录
public boolean isFile()         | 测试此抽象路径名表示的File是否为文件
public boolean exists()         | 测试此抽象路径名表示的File是否存在

public String getAbsolutePath() | 测试此抽象路径名的绝对路径名字符串
public String getPath()         | 将此抽象路径名转换为路径名字符串
public String getName()         | 返回由此抽象路径名表示的文件或目录的名称

public String[] list()          | 返回此抽象路径名表示的目录中的文件和目录的名称字符串数组
public File[]listFiles()        | 返回此抽象路径名表示的目录中的文件和目录的File对象数组
 */
public class FileDemo01 {
//    public static void main(String[] args){
//        //创建一个File对象
//        File f = new File("E:\\itcast\\java.txt");
////        public boolean isDirectory()    | 测试此抽象路径名表示的File是否为目录
//        System.out.println(f.isDirectory());
////        public boolean isFile()         | 测试此抽象路径名表示的File是否为文件
//        System.out.println(f.isFile());
////        public boolean exists()         | 测试此抽象路径名表示的File是否存在
//        System.out.println(f.exists());
////        public String getAbsolutePath() | 测试此抽象路径名的绝对路径名字符串
//        System.out.println(f.getAbsoluteFile());
////        public String getPath()         | 将此抽象路径名转换为路径名字符串
//        System.out.println(f.getPath());
////        public String getName()         | 返回由此抽象路径名表示的文件或目录的名称
//        System.out.println(f.getName());
////        public String[] list()          | 返回此抽象路径名表示的目录中的文件和目录的名称字符串数组
//        File f2 = new File("E:\\itcast");
//        String[] list = f2.list();
//        for (String str: list){
//            System.out.println(str);//没办法判断
//        }
////        public File[]listFiles()        | 返回此抽象路径名表示的目录中的文件和目录的File对象数组
//
//        File[] files = f2.listFiles();
//        for (File file:files){
//            System.out.println(file);//绝对路劲
//            System.out.println(file.getName());//文件名
//            if (file.isFile()){
//                System.out.println(file.getName());//判断他是否有文件，输出文件名称
//                //目录不管
//            }
//        }
//    }
public static void main(String[] args) throws IOException {
//    File f1 = new File("E:\\itcast\\java.txt");
    //需求1：在当前模块目录下创建java.txt文件
    File f1 = new File("java1.txt");
//    FileOutputStream f2 = new FileOutputStream("java.txt");
    System.out.println(f1.createNewFile());
    //需求2：在当前模块目录下的java.txt文件
    System.out.println(f1.delete());
    //需求3：在当前模块目录下创建itcast目录
    File f2 = new File("itcast");
//    System.out.println(f2.mkdir());
    //需求4：删除当前模块目录下的itcast目录
    System.out.println(f2.delete());
    //需求5：在当前模块下创建一个目录itcast，然后在该目录下创建一个java.txt文件
    File f3 = new File("itcast");
   // System.out.println(f3.mkdir());
    File f4 = new File("itcast\\java.txt");
   // System.out.println(f4.createNewFile());//直接执行f4，上级目录不存在就会抛出：IOException: 系统找不到指定的路径。
    //需求6：删除当前模块下的目录itcast
    System.out.println(f4.delete());
    System.out.println(f3.delete());//如果要删除的目录下有内容是删除不掉的
}
}
