package File;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

/*
需求：把文件fox.txt中的内容读取出来在控制台输出

FileInputStream(String name) :通过打开与实际文件的连接来创建一个FileInputStream，
                        该文件由文件系统中的路径名 name命名

 字节流读数据的步骤：
1. 创建字节输入流对象
2. 调用字节输入流对象的读数据方法
3. 释放资源
 */
public class FileInputStreamDemo {
    public static void main(String[] args) throws IOException {
        //1. 创建字节输入流对象
        FileInputStream fis = new FileInputStream("fos.txt");
        //2. 调用字节输入流对象的读数据方法
        //int read():从该输入流读取一个字节的数据
        //第一次读取
        int by  = fis.read();
        System.out.println(by);//     97
        System.out.println((char)by);//   a
        //第二次读取
        by  = fis.read();
        System.out.println(by);//     98
        System.out.println((char)by);//   b
        //再多次读取
        by  = fis.read();
        System.out.println(by);//     -1
        System.out.println((char)by);//   -1
        //如果到达文件末尾，返回-1
        //用循环改进

        int bs = fis.read();
        while (bs !=-1){
            System.out.print((char)bs);
            bs = fis.read();
        }
        //再次优化
        /*
        fis.read():读数据
        (by = fis.read())：把读取到的数据赋值给by
        !=-1：判断读取到的数据是否是-1
         */
        int ba;
        while ((ba = fis.read()) !=-1){
            System.out.print((char)ba);
        }
        //3. 释放资源
        fis.close();
    }
}
