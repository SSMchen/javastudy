package File;

import java.io.*;

/*
 InputStreamReader
java.IO包下，使用需要导包，是一个具体的类，继承自Reader
它是从字节流到字符流的桥梁：它读取字节，并使用指定的Charset将其解码为字符。它使用的字符集可以由名称指定，也可以被明确指定，或者可以接收平台的默认字符串
 OutputStreamWriter
java.IO包下，使用需要导包，是一个具体的类，继承自Writer
它是字符流到字节流的桥梁：使用指定的Charset将写入的字符编码为字节。它使用的字符集可以由名称指定。也可以被明确指定，或者可以接收平台的默认字符集。
 */
public class ConversionStreamDemo {
    public static void main(String[] args) throws IOException {
//OutputStreamWriter(OutputStream out)     创建一个使用默认字符缩码的OutputStreamWriter
//OutputStreamWriter(OutputStream out,String charsetName)创建一个使用命名字符集的OutputStreamWriter
//        FileOutputStream fos = new FileOutputStream("osw.txt");
//        OutputStreamWritert osw = new OutputStreamWriter(fos);
//        OutputStreamWriter osw = new OutputStreamWriter(new FileOutputStream("osw.txt"),"UTF-8");
        OutputStreamWriter osw = new OutputStreamWriter(new FileOutputStream("osw.txt"),"GBK");
        osw.write("中国");
        osw.close();
// InputStreamReader(InputStream in) 创建一个使用默认字符集的InputStreamReader
//InputStreamReader(InputStream in, String charsetName) 创建一个使用命名字符集的InputStreamReader
        InputStreamReader isr = new InputStreamReader(new FileInputStream("osw.txt"),"GBK");
        //一次读取一个字符数据
        int ch;
        while ((ch= isr.read())!=-1){
            System.out.print((char) ch);
        }
        isr.close();
    }

}
