package File;

import java.io.FileOutputStream;
import java.io.IOError;
import java.io.IOException;

/*
字节流写数据加入异常处理
 */
public class FileOutptuStreamException {
    public static void main(String[] args) {
        //加入finally来实现释放资源
        FileOutputStream box=null;
        try {
            //创建输出字符流对象
             box = new FileOutputStream("a.txt");
            //调用write写了一个字节数组的数据
            box.write("hello".getBytes());
            //如果在做write的动作时出现了IOException就会去到  e.printStackTrace()，释放资源的动作就没有执行到
        }catch (IOException e){
            e.printStackTrace();
        }finally {
            if (box !=null) {
                //释放资源
                try {
                    box.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

    }
}