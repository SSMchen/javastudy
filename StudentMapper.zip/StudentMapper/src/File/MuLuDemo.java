package File;

import java.io.File;

/*
需求：给定一个路径(E:\\itcast),请通过递归完成该目录下的所有内容，并把所有文件的绝对路径输出在控制台上(通过递归完成)

思路：
1. 根据给定的路径创建一个File对象
2. 定义一个方法，用于获取给定目录下的所有内容，参数为第1步创建的File对象
3. 获取给定的File目录下所有的文件或者目录的File数组
4. 遍历该File数组，得到每一个File对象
5. 遍历该File数组，得到每一个File对象
是：递归调用
不是：获取绝对路径输出在控制台
6. 调用方法
 */
public class MuLuDemo {
    public static void main(String[] args) {
    //  1. 根据给定的路径创建一个File对象
//        File srcfile = new File("E:\\itcast");
        File srcfile = new File("E:\\作业");

//6. 调用方法
        getAllFilePath(srcfile);

    }
    //2. 定义一个方法，用于获取给定目录下的所有内容，参数为第1步创建的File对象
    public static void getAllFilePath(File srcFile){
        //3. 获取给定的File目录下所有的文件或者目录的File数组
        File[] fileArray = srcFile.listFiles();
        //4. 遍历该File数组，得到每一个File对象
        if (fileArray != null){
            for (File file :fileArray){
                //5. 遍历该File数组，得到每一个File对象
                if (file.isDirectory()){        //规则：如果他是目录就调用递归
                    //是：递归调用
                    getAllFilePath(file);
                }else{
                    //不是：获取绝对路径输出在控制台          出口！！
                    System.out.println(file.getAbsolutePath());
                }
            }
        }
    }
}
