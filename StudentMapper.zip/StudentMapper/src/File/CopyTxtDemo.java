package File;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

/*
需求：把"E:\  \itcast\ \窗里窗外.txt"复制到模块目录下的"窗里窗外.txt"
 数据源：
E:\  \itcast\ \窗里窗外.txt 读数据   ----采用InputStream----因为是一个抽象类，所以使用----FileInputStream实现
目的地
E:\  \itcast\ \窗里窗外.txt 写数据   ----采用OutputStream---因为是一个抽象类，所以使用-----FileOutputStream实现
 思路：
1. 根据数据源创建字节输入流对象
2. 根据目的地创建字节输出流对象
3. 读写数据，复制文本文件（一次读取一个字节，一次写入一个字节）
4. 释放资源
 */
public class CopyTxtDemo {
    public static void main(String[] args) throws IOException {
        //1. 创建字节输入流对象
        FileInputStream fis = new FileInputStream("fos.txt");

        //2. 调用字节输入了对象的读数据方法
//int read(byte[] b)从该输入流读取最多b.length个字节的数据到一个字节数组
        byte[] bys =  new byte[5];
        //第一次读取数据
        int len=fis.read(bys);
        System.out.println(len);//5
        //转换为字符串输出
        //用到String构造方法：
        // String(byte[] bytes):通过使用平台的默认字符集解码指定的字节数组来构造新的String
        System.out.println(new String(bys,0,len));//hello
        //第er次读取数据
        len=fis.read(bys);
        System.out.println(len);//5
        System.out.println(new String(bys,0,len));//空行。wor
        //第san次读取数据
        len=fis.read(bys);
        System.out.println(len);//4
        //String(byte[] bytes,int offset,int length)通过使用平台的默认字符集解码指定的字节子阵列来构造新的String
        System.out.println(new String(bys,0,len));//ld\r\nr
//再多读取两次
        len=fis.read(bys);
        System.out.println(len);//-1
        len=fis.read(bys);
        System.out.println(len);//-1

        /*
        len 是实际读取数据的个数

        hello\r\n
        world\r\n

        第一次:hello
        第二次:\r\nwor
        第三次:ld\r\n
         */
        //用循环改进
//        byte[] bys = new byte[1024];//1024及其整数倍
//        int len;
        while ((len=fis.read(bys))!=-1){
            System.out.println(new String(bys,0,len));
        }
        //3. 释放资源
        fis.close();



//        //根据数据源创建字节输入流对象
//        FileInputStream fis = new FileInputStream("E:\\itcast\\窗里窗外.txt");
//        //2. 根据目的地创建字节输出流对象
//        FileOutputStream fos = new FileOutputStream("窗里窗外.txt");
//        //3. 读写数据，复制文本文件（一次读取一个字节，一次写入一个字节）
//        int by;
//        while ((by=fis.read())!=-1){
//            fos.write(by);
//        }
//        //释放资源
//        fos.close();
//        fis.close();
    }
}
