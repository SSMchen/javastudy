package DuoTai;

public class Animal {
    public int age = 40;
    public void eat(){
        System.out.println("动物吃东西");
    }
}
