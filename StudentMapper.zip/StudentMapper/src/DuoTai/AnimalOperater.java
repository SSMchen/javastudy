package DuoTai;
/*
动物操作类
 */
public class AnimalOperater {
    /*
    public void useAnimal(Cat c){
        c.eat();
    }
    public void useAnimal(Dog d){d.eat();
    }

     */
    public void useAnimal(Animal a){
        a.eat();
    }
}
