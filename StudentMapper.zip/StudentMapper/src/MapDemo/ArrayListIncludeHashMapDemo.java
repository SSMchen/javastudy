package MapDemo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;

/*
需求：创建一个ArrayList集合存储三个元素，每一个元素都是HashMap，
每一个HashMap的键和值都是String，并遍历
思路：
1. 创建ArrayList集合
2. 创建HashMap集合，并添加键值对元素
3. 把HashMap作为元素添加到ArrayList集合
4. 遍历ArrayList集合
给出如下的数据 ：
    第一个HashMap集合的元素：
        孙策  大乔
        周瑜  小乔
    第二个HashMap集合的元素：
        郭靖  黄蓉
        杨过  小龙女
    第三个HashMap集合的元素：
        令狐冲 任盈盈
        林平之 岳灵珊
 */
public class ArrayListIncludeHashMapDemo {
    public static void main(String[] args) {
//1. 创建ArrayList集合
        ArrayList<HashMap<String,String>> array = new ArrayList<HashMap<String,String>>();
//2. 创建HashMap集合，并添加键值对元素
        HashMap<String,String> hml = new HashMap<String,String>();
        hml.put("孙策","大乔");
        hml.put("周瑜","小乔");
//3. 把HashMap作为元素添加到ArrayList集合
        array.add(hml);
//三个HashMap对象，执行三次以上代码
        HashMap<String,String> hml1 = new HashMap<String,String>();
        hml1.put("郭靖","黄蓉");
        hml1.put("杨过","小龙女");
        array.add(hml1);
        HashMap<String,String> hml2 = new HashMap<String,String>();
        hml2.put("令狐冲","任盈盈");
        hml2.put("林平之","岳灵珊");
        array.add(hml2);

//4. 遍历ArrayList集合
        for (HashMap<String, String> sst: array) {
//            Set<String> keySet = sst.keySet();
            for (String key : sst.keySet()) {
                //String value = sst.get(key);
                System.out.println(key+','+sst.get(key));
            }
        }
    }
}
