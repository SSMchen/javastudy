package MapDemo;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/*
转换为Map集合中的操作：
 1. 获取所有键值对对象的集合
    Set<Map.Entry<K,V>>entrySet():获取所有键值对对象的集合
 2. 遍历键值对对象的集合，得到每一个键值对对象
    用增强for实现，得到每个Map.Entry
 3. 根据键值对对象获取键和值
    k  --getKey()
    v   --getValue()
 */
public class MapDemoB {
    public static void main(String[] args) {
        Map<String,String> map= new HashMap<String,String>();
        // V put(K key,V vlaue)     | 添加元素                             |
        map.put("张无忌","赵敏");
        map.put("郭靖","黄蓉");
        map.put("杨过","小龙女");
        //获取所有的键值对对象的集合
        Set<Map.Entry<String, String>> entrySet = map.entrySet();
        for (Map.Entry<String, String> Entry : entrySet) {
            //根据兼职对对象获取键和值
//            String key = Entry.getKey();
//            String value = Entry.getValue();
            System.out.println(Entry.getKey()+","+Entry.getValue());
        }
    }
}
