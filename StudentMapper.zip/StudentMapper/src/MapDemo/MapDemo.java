package MapDemo;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/*
举例： 学生的学号和姓名
   20219210037  林青霞
   20219210065  张曼玉
   20219210068  王祖贤
创建Map集合的对象
    多态的方式
    具体的实现类HashMap

 */
public class MapDemo {
    public static void main(String[] args) {
//        //创建集合对象
//        Map<String,String> map= new HashMap<String,String>();
//        //  V put(k key ,V value) 将指定的值与该映射中的指定键相关联
//        map.put("20219210037","林青霞");
//        map.put("20219210065","张曼玉") ;
//        map.put("20219210068","王祖贤");
//        map.put("20219210068","柳岩");//当键重复时，后值会替代掉之前的值
//        //输出集合对象
//        System.out.println(map);
/*
| V put(K key,V vlaue)                | 添加元素                             |
| ----------------------------------- | ------------------------------------ |
| V remove(Object key)                | 根据键删除键值对元素                 |
| void clear()                        | 移除所有的键值对元素                 |
| bollean containsKey(Object key)     | 判断集合是否包含指定的键             |
| bollean containsValue(Object value) | 判断集合是否包含指定的值             |
| bollean isEmpty()                   | 判断集合是否为空                     |
| int size()                          | 集合的长度，也就是集合中键值对的个数 |
 */
        Map<String,String> map= new HashMap<String,String>();
        // V put(K key,V vlaue)     | 添加元素                             |
        map.put("张无忌","赵敏");
        map.put("郭靖","黄蓉");
        map.put("杨过","小龙女");
//V get(Object key)  根据键获取值
        System.out.println(map.get("张无忌"));
        System.out.println(map.get("张三丰"));//不存在的键，则返回null
//Set<K> keySet()获取所有键的集合
        Set<String> keySet = map.keySet();
        for (String key:keySet){
            System.out.println(key);
        }
//Collection<V>values()获取所有值的集合
        Collection<String> values = map.values();
        for (String value:values){
            System.out.println(value);
        }
//Set<Map.Entry<K,V>>entrySet()获取所有键值对对象的集合
        Set<Map.Entry<String, String>> entries = map.entrySet();
            System.out.println(entries);
        for (Map.Entry<String, String> entry : entries) {
            System.out.println(entry.getKey()+" 爱"+entry.getValue());

       //understand?明白了  这个for你咋写出来的
        }
        /**
         * 先集合
         * 然后.
         * for一哈
         * 就出来了
         */
        for (Map.Entry<String, String> entry : entries) {

        }

/*Map集合的基本功能
        // V remove(Object key)    | 根据键删除键值对元素                 |
        System.out.println(map.remove("郭靖"));//删除键值对，按照键删除，返回键值对的值
        System.out.println(map.remove("郭襄"));//不存在的键返回后的值为null
        // void clear()  | 移除所有的键值对元素                 |
        map.clear();//清除所以键值对
        // bollean containsKey(Object key)     | 判断集合是否包含指定的键
        System.out.println(map.containsKey("郭靖"));//存在则返回true
        System.out.println(map.containsKey("郭襄"));//不存在则返回false
        // bollean containsValue(Object value) | 判断集合是否包含指定的值
        System.out.println(map.containsValue("小龙女"));//存在则返回true
        System.out.println(map.containsValue("浣碧"));//不存在则返回false
        //bollean isEmpty()                   | 判断集合是否为空
        System.out.println(map.isEmpty());
        //int size()                          | 集合的长度，也就是集合中键值对的个数
        System.out.println(map.size());
        System.out.println(map);
 */

    }
}
