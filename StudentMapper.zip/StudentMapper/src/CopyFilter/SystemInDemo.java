package CopyFilter;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Scanner;

public class SystemInDemo {
    public  static void main(String[] args) throws IOException {
        //public static final InputStream in:标准输入流
        //   in 是InputStream类型的被final修饰说明她是个常量，被static修饰说明他可以直接通过类名访问
    //1.    InputStream is = System.in;
        //字节流读汉字不方便
        //InpytStream 是字节输入流的抽象基类，采用多态的形式完成了对is的初始化
//        int by;
//        while ((by=is.read())!=-1){
//            System.out.println((char)by);
//        }
        //如何把字节流转换为字符流？用转换流
    //2.   InputStreamReader isr = new InputStreamReader(is);
        //使用字符流能不能够，实现一次读取一行数据呢
        //但是一次读取一行数据的方法是字符缓冲输出流的特殊方法
    // 3.  BufferedReader br = new BufferedReader(isr);
        //123组合
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("请输入一个字符串：");
        String line = br.readLine();
        System.out.println("你输入的字符串是："+line);
        System.out.println("请输入一个整数：");
        int i = Integer.parseInt(br.readLine());//用类型的包装类类型进行转换输出
        System.out.println("你输入的整数是："+i);
//由于自己实现键盘录入数据太麻烦，所以java提供了一个方法供开发者实现键盘录入
        Scanner sc = new Scanner(System.in);

    }
}

