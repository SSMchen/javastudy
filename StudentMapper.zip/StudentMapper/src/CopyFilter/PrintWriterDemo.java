package CopyFilter;

import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

/*
PrintWriter(String fileName)使用指定的文件名创建一个新的PrintWriter，而不需要自动执行行刷新

PrintWriter(Writer out, boolean autoFlush)创建一个新的PrintWriter
    out：字符输出流
    如果Boolean为真，则println，printf或format方法将刷新输出缓冲区
*/
public class PrintWriterDemo {
    public static void main(String[] args) throws IOException {
       // PrintWriter(String fileName)使用指定的文件名创建一个新的PrintWriter，而不需要自动执行行刷新
        PrintWriter pw = new PrintWriter("ps.txt");
        pw.write("hello");
        pw.flush();
        pw.write("world");
        pw.flush();//两个单词在同一行


        pw.write("hello");
        pw.write("\r\n");//换行符
        pw.flush();
        pw.write("world");
        pw.write("\r\n");//换行符
        pw.flush();

        pw.println("hello");
        /*
        pw.write("hello");
        pw.write("\r\n");//换行符
        */
        pw.flush();//手动flush
        pw.println("world");
        pw.flush();
        //PrintWriter(Writer out, boolean autoFlush)创建一个新的PrintWriter
        //    out：字符输出流
        //    如果Boolean为真，则println，printf或format方法将刷新输出缓冲区
        PrintWriter pws = new PrintWriter(new FileWriter("ps.txt"),true);
        pws.println("hello");//自动刷新
        /*
        相当于
        pw.write("hello");
        pw.write("\r\n");//换行符
        pw.flush();//手动flush
         */
        pws.println("world");
    }
}
