package CopyFilter;

import java.io.*;

/*
需求：把“E:\\itcast”这个文件夹复制到模块目录下
思路：
1. 创建数据源目录File对象，路径是E：\\\itcast
2. 通过获取数据源目录File对象获取对象名称（itcast）
3. 创建目的地目录file对象，路径是模块名+itcast组成
4. 判断目的地目录对应的File是否存在，如果不存在，就创建
5. 获取数据源目录下所以文件的File数组
6. 遍历File数组，的带每一个File对象，该File对象，其实就是数据源文件
   1. 数据源文件：E：\\\itcast\\\mn.jpg
7. 获取数据源文件File对象的名称（mn.jpg）
8. 创建目的地文件File对象，路径名是目的地目录+mn.jpg组成
9. 复制文件
   由于文件不仅仅是文本文件，还有图片，视频等文件，所以采用字节流复制文件
 */
public class CopyFolder {
    public static void main(String[] args) throws IOException {
        //1. 创建数据源目录File对象，路径是E：\\\itcast
        File srcFolder = new File("E:\\itcast");
//        File srcFolder = new File("E:\\IdeaProjects\\StudentMapper");
        //2. 通过获取数据源目录File对象获取对象名称（itcast）
        String srcFolderName = srcFolder.getName();
        //3. 创建目的地目录file对象，路径是模块名+srcFolderName组成
//        File destFolder = new File("StudentMapper",srcFolderName);
        File destFolder = new File("E:\\IdeaProjects\\StudentMapper",srcFolderName);
        //4. 判断目的地目录对应的File是否存在，如果不存在，就创建
        if (!destFolder.exists()){
            destFolder.mkdir();
        }

        //5. 获取数据源目录下所以文件的File数组
        File[] listFiles = srcFolder.listFiles();
        //6. 遍历File数组，的带每一个File对象，该File对象，其实就是数据源文件
        for (File srcFile : listFiles){
            // 6.1数源文件：E：\\\itcast\\\mn.jpg
            //7. 获取数据源文件File对象的名称（mn.jpg）
            String srcFileName = srcFile.getName();
            //8. 创建目的地文件File对象，路径名是目的地目录+mn.jpg组成
            File destFile = new File(destFolder,srcFileName);
            //9. 复制文件
            copyFile(srcFile,destFile);
        }
    }

    private static void copyFile(File srcFile, File destFile) throws IOException {
        BufferedInputStream bis = new BufferedInputStream(new FileInputStream(srcFile));
        BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(destFile));

        //一次读写一个字节数组的方式
        byte[] bys = new byte[1024];
        int len;
        while ((len=bis.read(bys))!=-1){
            bos.write(bys,0,len);
        }
        bos.close();
        bis.close();

    }
}
