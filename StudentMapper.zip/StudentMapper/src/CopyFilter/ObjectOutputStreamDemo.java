package CopyFilter;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

/*
对象序列化流
构造方法：
 ObjectOutputStream(OutputStream out) 创建一个写入指定的OutputStream的ObjectOutputStream
序列化对象的方法
 void writeObject（Object obj）   将指定的对象写入ObjectOutputStream

 NotSerializableException：抛出一个实例需要一个Serializable接口。序列化运行时或实例的类可能会抛出异常。
        类的序列化有实现java.io.Serializable接口的类启用，不实现此接口的类将不会使任何状态序列化或反序列化
        可序列化类的所有子类型都是可序列化的。
        序列化接口没有方法或字段，仅用于表示可串行化的语义
 */
public class ObjectOutputStreamDemo {
    public static void main(String[] args) throws IOException {
        // ObjectOutputStream(OutputStream out) 创建一个写入指定的OutputStream的ObjectOutputStream'
        ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("oos.txt"));
        //新建学生类 Student
        //创建对象   采用带参构造
        Student s = new Student("林青霞",30);
        // void writeObject（Object obj）   将指定的对象写入ObjectOutputStream
        oos.writeObject(s);
        //释放资源
        oos.close();
    }
    /*
    序列化流结果：
    �� sr CopyFilter.Student�|nકX� I ageL namet Ljava/lang/String;xp   t 	林青霞
     */
}
