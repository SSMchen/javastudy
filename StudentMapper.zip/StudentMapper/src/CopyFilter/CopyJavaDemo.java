package CopyFilter;

import java.io.*;

/*
需求：把模块目录下的PrintStreamDemo.java复制到模块目录下的Copy.java

思路:
1. 根据数据源创建字符输入流对象
2. 根据目的地创建字符输出了对象
3. 读写数据，复制文件
4. 释放资源
 */
public class CopyJavaDemo {
    public static void main(String[] args) throws IOException {
        FileOutputStream fileOutputStream = new FileOutputStream("a");

        //1. 根据数据源创建字符输入流对象
        //创建字符输入流对象
//        BufferedReader br = new BufferedReader(new FileReader("StudentMapper\\PrintStreamDemo.java"));
        BufferedReader br = new BufferedReader(new FileReader("src/CopyFilter/PrintStreamDemo.java"));
        //2. 根据目的地创建字符输出了对象
        //创建字符输出流对象
        BufferedWriter bw = new BufferedWriter(new FileWriter("copyprintstream.java"));

        //3. 读写数据，复制文件
        String line;
        while ((line = br.readLine())!=null){
            bw.write(line);
            bw.newLine();
            bw.flush();
        }
//        4. 释放资源
        bw.close();
        br.close();

        //根据数据源创建字符输入流对象
        BufferedReader brs = new BufferedReader(new FileReader("src/CopyFilter/PrintStreamDemo.java"));
        //根据目的地创建字符输出流对象
        PrintWriter pw = new PrintWriter(new FileWriter("copy2.java"),true);

        //3. 读写数据，复制文件
        String lines;
        while ((lines = br.readLine())!=null){
            pw.println(lines);
        }
        //        4. 释放资源
        pw.close();
        brs.close();
    }
}
