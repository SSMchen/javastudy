package CopyFilter;

import java.io.PrintStream;

public class SystemOutDemo {
    public static void main(String[] args){
        //public static final PrintStream out:标准输出流
        PrintStream ps = System.out;
        // 能够方便地打印各种数据值
//        ps.print("hello");
//        ps.print(100);   不换行
//        ps.println("hello");
//        ps.println(100);    换行
        System.out.println();
//        System.out.print();//必须带参数
    }
}
