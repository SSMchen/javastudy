package CopyFilter;

import java.io.*;

/*
思路：
1. 创建数据源File对象，路径是E：\\\itcast
2. 创建目的地File对象，路径是F：\\\
3. 写方法实现文件夹的复制，参数为数据源file对象和目的地File对象
4. 判断数据源File是否是目录
   1. 是：
      A. 在目的地下创建和数据源File名称一样的目录
      B. 获取数据源File下所以文件或者目录的File数组
      C. 遍历该File数组，得到每一个File对象
      D. 把该File作为数据源File对象，递归调用复制文件夹的方法
   2. 不是： 说明是文件，直接复制，用字节流


 */
public class CopyFolders  {
    public static void main(String[] args) throws IOException{
        //1. 创建数据源File对象，路径是E：\\itcast
        File srcFile = new File("E:\\itcast");
        //2. 创建目的地File对象，路径是F：\\
        File destFile = new File("D:\\");
        //3. 写方法实现文件夹的复制，参数为数据源file对象和目的地File对象
        copyFolder(srcFile,destFile);
    }

    //复制文件夹
    private static void copyFolder(File srcFile , File destFile) throws IOException {
        //4. 判断数据源File是否是目录
        if (srcFile.isDirectory()){
            //1. 是：
            //A. 在目的地下创建和数据源File名称一样的目录
            String srcFileName = srcFile.getName();
            //封装一下新的目录           D盘这个路径     C盘路径
            File newFolder = new File(destFile,srcFileName);//D盘下对应的itcast
            //路径封装好要创建他
            if (!newFolder.exists()){
                newFolder.mkdir();//判断是否存在，不存在则创建
            }
            //B. 获取数据源File下所以文件或者目录的File数组
            File[] fileArray = srcFile.listFiles();
            //C. 遍历该File数组，得到每一个File对象    用增强for来遍历
            for (File file:fileArray){
                //file  可能是文件也可能是文件夹，所以递归调用
                //D. 把该File作为数据源File对象，递归调用复制文件夹的方法
                //        作为数据源的file对象   newFolder是新创建的目录
                copyFolder(file,newFolder);
            }
        }else {
            //2. 不是：
            // 说明是文件，直接复制，用字节流
            //copyFile (源文件，目的地文件)
            File newFile = new File(destFile,srcFile.getName());
            //放在目的地中去的所以是的destFile   对应的名称是srcFile.getName
            copyFile(srcFile,newFile);
        }
    }
    //字节缓冲流复制
    private static void copyFile(File srcFile, File destFile) throws IOException {
        BufferedInputStream bis = new BufferedInputStream(new FileInputStream(srcFile));
        BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(destFile));
        //一次读写一个字节数组的方式
        byte[] bys = new byte[1024];
        int len;
        while ((len=bis.read(bys))!=-1){
            bos.write(bys,0,len);
        }
        bos.close();
        bis.close();

    }
}
