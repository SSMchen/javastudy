import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

/*
   Iterator：迭代器，集合的专用遍历方式
       Iterator<E> iterator（）:返回此集合中元素的迭代器，通过集合的Iterator()方法得到
       迭代器是通过集合的iterator()方法得到的，所以我们说它是依赖于集合而存在的
   Iterator中的常用方法
       E next()：返回迭代中的下一个元素
       Boolean hasNext():如果迭代具有更多元素，则返回True
    */
public class Iteratordemo {
    public static void main(String[] args) {
        //创建集合对象
        Collection<String> c= new ArrayList<String>();

        //添加元素
        c.add("hello");
        c.add("world");
        c.add("Java");
        //Iterator<E> iterator（）:返回此集合中元素的迭代器，通过集合的Iterator()方法得到
        Iterator<String> i = c.iterator();
//        // E next()：返回迭代中的下一个元素
//        System.out.println(i.next());//多于元素迭代次数NoSuchElementException:表示被请求的元素不存在
//
//        //Boolean hasNext():如果迭代具有更多元素，则返回True
//        if (i.hasNext()){
//            System.out.println(i.next());
//        }
        while (i.hasNext()){
//            System.out.println(i.next());
            String s = i.next();
            System.out.println(s);
        }
        /*
public Iterator<E> iterator(){
    return new Itr();
}
private class itr implements Iterator<E>{
    ...
}
 */

    }

}
