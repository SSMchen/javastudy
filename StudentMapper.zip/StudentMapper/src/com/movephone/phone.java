package com.movephone;
/*
手机类
 */
public class phone {
    public void call(String name){
        System.out.println("给"+name+"打电话");
    }
}
