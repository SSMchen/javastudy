package com.movephone;
/*
测试类
 */
public class phonetest {
    public static void main(String[] args) {
        //创建对象，调用方法
        phone p = new phone();
        p.call("小林子");
        System.out.println("--------");
        newphone np = new newphone();
        np.call("小王子");
    }
}
