package com.movephone;

public class newphone extends phone {
//    public void call(String name){
//        System.out.println("开启视频功能");
////        System.out.println("给"+name+"打电话");
//        super.call(name);
//    }
    @Override//注解，帮我们检查重写声明时的正确性
    public void call(String name){
        System.out.println("开启视频功能");
//        System.out.println("给"+name+"打电话");
        super.call(name);
    }
}
