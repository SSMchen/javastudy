package com.family;

public class Granddad {
    public void drink(){
        System.out.println("爷爷爱喝酒");
    }
}
