package com.family;

public class Mother {
    public void dance(){
        System.out.println("妈妈爱跳舞");
    }
}
