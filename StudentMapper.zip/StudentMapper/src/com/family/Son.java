package com.family;

public class Son extends Father {
}