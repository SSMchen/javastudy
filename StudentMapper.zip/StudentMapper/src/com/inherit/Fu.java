package com.inherit;

public class Fu {
    public void show(){
        System.out.println("show方法被调用");
    }
}
