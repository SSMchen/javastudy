package com.inherit;
/*
测试类
继承的格式： public class 子类名 extends 父类名{}
          范例： public class Zi extends Fu{}
          Fu:是父类，也称为基类，超类
          Zi：是子类，也称为派生类
     子类可以有父类的内容
     也可以有自己特有的内容

*/
public class Demo {
    public static void main(String[] args) {
        //创建对象，调用方法
        Fu f= new Fu();
        f.show();

        Zi z=new Zi();
        z.method();
        z.show();
    }
}
