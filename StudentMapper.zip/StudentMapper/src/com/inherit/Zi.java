package com.inherit;

public class Zi extends Fu {
    public void method(){
        System.out.println("method的方法呗调用");
    }
}
