package com.StudentAndTeacher;

public class Teacher extends Person {
    public Teacher(String name,int age){
        super(name,age);
    }
    public Teacher(){}
    public void teach(){
        System.out.println("爱你孤身走暗巷");
    }
}
