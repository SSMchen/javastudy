package com.StudentAndTeacher;

public class Student extends Person {
    public Student(String name,int age){
        super(name,age);
    }
    public Student(){}
    public void study (){
        System.out.println("好好学习，天天向上");
    }
}
