package com.StudentAndTeacher;
/*
测试类
1.定义老师类（姓名，年龄，教书（））
2.定义学生类（姓名，年龄，学习（））
3.蒂尼测试类，写代码测试
4.共性抽取父类，定义人类（姓名，年龄两个成员变量，还有对应的getset方法，
   作为父类                  还有无参构造方法和带参构造方法）
5.定义老师类，继承人类，并给出自己特有的方法：教书（）
6.定义学生类，继承人类，并给出自己特有的方法：学习（）
7.定义测试类，写代码测试
 */
public class Demo {
    public static void main(String[] args) {
        //创建老师类对象进行测试
        Teacher t1= new Teacher();
        t1.setName("林青霞");
        t1.setAge(18);
        System.out.println(t1.getName()+","+t1.getAge());
        t1.teach();

        Student s1= new Student("孟晨",30);
        System.out.println(s1.getName()+","+s1.getAge());
        s1.study();

//        Teacher t2 = new Teacher("孟孟",20);
//        System.out.println(t2.getName()+","+t2.getAge());
//        t2.teach();

    }
}
