package com.company;
/*
1.定义学生类
2.主界面的代码编写
    1.用输出语句完成主界面的编写
    2.用Scanner实现键盘录入数据
    3.用Switch语句完成操作的选择
    4.用循环完成再次回到主界面
3.添加学生的代码编写
    1.用键盘录入选择添加学生
    2.定义一个方法，用于添加学生
        1.显示提示信息，提示要输入何种信息
        2.键盘录入学生对象所需要的数据
        3.创建学生对象，把键盘录入的数据赋值给学生对象的成员变量
        4.讲学生对象添加到集合中（保存）
        5.给出添加成功的提示
     3.调用方法
4.查看学生的代码编写
    1.用键盘录入选择查看所有学生的信息
    2.定义一个方法，用于查看学生信息
        1.显示表头信息
        2.将集合中数据取出按照对应格式显示学生信息，年龄显示补充“岁”
    3.调用方法
5.删除学生的代码编写
    1.用键盘录入选择删除学生信息
    2.定义一个方法，用于删除学生信息
        1.显示提示信息/请输入你要删除学生的学号
        2.键盘录入要删除的学生学号
        3.遍历集合讲对应学生对象从集合中删除
        4.给出删除成功提示
    3.调用方法
6.修改学生的代码编写
    1.键盘录入选择修改学生信息
    2.定义方法，用于修改学生信息
        1.显示提示信息/请输入你要修改的学生学号
        2.键盘录入要修改的学生学号
        3.键盘录入要修改的学生信息
        4.遍历集合修改对应的学生信息
        5.给出修改成功的提示
    3.调用方法
*/

import java.util.ArrayList;
import java.util.Scanner;

//学生管理系统
public class StudentManager {
//2.主界面的代码编写
//    1.用输出语句完成主界面的编写
//    2.用Scanner实现键盘录入数据
//    3.用Switch语句完成操作的选择
//    4.用循环完成再次回到主界面
    public static void main(String[] args) {
        //创建集合对象用于存储学生数据
        ArrayList<Student> array= new ArrayList<>();
        //    4.用循环完成再次回到主界面
        while(true) {
            //    1.用输出语句完成主界面的编写
            System.out.println("--------欢迎来到学生管理系统--------");
            System.out.println("1 添加学生");
            System.out.println("2 删除学生");
            System.out.println("3 修改学生");
            System.out.println("4 查看所有学生");
            System.out.println("5 退出");
            System.out.println("请输入你的选择：");

            //    2.用Scanner实现键盘录入数据
            Scanner sc = new Scanner(System.in);
            String line = sc.nextLine();

            //    3.用Switch语句完成操作的选择
            switch (line) {
                case "1":
//                    System.out.println("添加学生");
                    addStudent(array);
                    break;
                case "2":
                    //System.out.println("删除学生");
                    deleteStudent(array);
                    break;
                case "3":
                    //System.out.println("修改学生");
                    updateStudent(array);
                    break;
                case "4":
                    //System.out.println("查看所有学生学生");
                    findStudent(array);
                    break;
                case "5":
                    System.out.println("谢谢使用");
//                    break;
                    System.exit(0);
            }
        }

    }
    //定义一个方法，用于添加学生信息
    public static void addStudent(ArrayList<Student> array){
//        1.显示提示信息，提示要输入何种信息
//        2.键盘录入学生对象所需要的数据
        Scanner sc= new Scanner(System.in);
        //为了让sid在while循环外面呗访问到，
        String sid;
        //为了让程序回到着了，使用循环实现
        while (true) {
            System.out.println("请输入学生学号");
            sid = sc.nextLine();
            boolean flag = isUsed(array, sid);
            if (flag) {
                System.out.println("你输入的学号已被占用，请重新输入");
            }else {
                break;
            }
        }
            System.out.println("请输入学生姓名");
            String name = sc.nextLine();
            System.out.println("请输入学生年龄");
            String age = sc.nextLine();
            System.out.println("请输入学生居住地");
            String address = sc.nextLine();
//              3.创建学生对象，把键盘录入的数据赋值给学生对象的成员变量
            Student s = new Student();
            s.setSid(sid);
            s.setName(name);
            s.setAge(age);
            s.setAddress(address);
//               4.讲学生对象添加到集合中（保存）
            array.add(s);
//            5.给出添加成功的提示
            System.out.println("添加成功");


    }
    //定义一个方法，用于查找学生信息
    public static void findStudent(ArrayList<Student> array){
        //1.1判定集合中是否有数据，如果没有，显示提示信息
        if (array.size()==0){
            System.out.println("无信息，请先添加信息再查询");
            //为了让程序不再向下执行，给出return；
            //return有一个特性就是一旦调用return那么直接结束方法
            return;

        }
//        1.显示表头信息
        //\t是一个tab键
        System.out.println("学号\t\t\t\t姓名\t\t\t年龄\t\t居住地");
//        2.将集合中数据取出按照对应格式显示学生信息，年龄显示补充“岁”
        for (int i=0; i< array.size();i++){
            Student s= array.get(i);
            System.out.println(s.getSid() + "\t\t" + s.getName() + "\t\t\t" + s.getAge() + "岁" + "\t" + s.getAddress());
        }
    }
    //定义一个方法，用于删除学生信息
    public static void deleteStudent(ArrayList<Student> array){
        // 1.用键盘录入选择删除学生信息
        Scanner sc = new Scanner(System.in);
        System.out.println("请输入你要删除学生的学号");
        //2.键盘录入要删除的学生学号
        String sid = sc.nextLine();
        //3.遍历集合讲对应学生对象从集合中删除
        int index =-1;
        for (int i = 0;i< array.size();i++){
            Student s = array.get(i);
            //getSid()是字符串  所以用equals对两个字符串进行比较
            if (s.getSid().equals(sid)){
//                int index=i;
                index=i;

                break;
            }
        }
        if (index==-1){
            System.out.println("该信息不存在，请重新输入");
        }else {
            array.remove(index);
            //4.给出删除成功提示
            System.out.println("删除成功");
        }

    }
    //定义一个方法，用于修改学生信息
    public static void updateStudent(ArrayList<Student> array){
//        1.键盘录入选择修改学生信息
//        2.定义方法，用于修改学生信息
//          1.显示提示信息/请输入你要修改的学生学号
//          2.键盘录入要修改的学生学号
//          3.键盘录入要修改的学生信息
//          4.遍历集合修改对应的学生信息
//          5.给出修改成功的提示
//        3.调用方法
        //1.显示提示信息/请输入你要修改的学生学号/2.键盘录入要修改的学生学号
        Scanner sc= new Scanner(System.in);
        System.out.println("请输入你要修改的学生学号");
        String sid = sc.nextLine();
        int index=-1;
        //4.遍历集合修改对应的学生信息
        for (int i = 0 ;i<array.size();i++){
            Student student = array.get(i);
            if (student.getSid().equals(sid)){
                index=i;
                break;
            }
        }
        if (index==-1){
            System.out.println("你输入的信息有误，请重新输入");
            return;
        }else {
            //3.键盘录入要修改的学生信息
            System.out.println("请输入学生新姓名：");
            String name =sc.nextLine();
            System.out.println("请输入学生新年龄：");
            String age =sc.nextLine();
            System.out.println("请输入学生新居住地：");
            String address =sc.nextLine();

            //创建学生对象
            Student s = new Student();
            s.setSid(sid);
            s.setName(name);
            s.setAge(age);
            s.setAddress(address);

            array.set(index, s);
        }
        //5.给出修改成功的提示
        System.out.println("修改成功");
    }
    //定义一个方法，对学号是否被使用进行判断
    public static boolean isUsed(ArrayList<Student> array,String sid){
        //如果与集合中的某一个学生学号相同，返回true。如果都不相同，返回false
        boolean flag=false;
        //在添加学生录入学号后调用该方法/
        // 如果返回true，弹出提示，重新输入学号/如果返回false，正常添加学生对象
        for (int i=0;i< array.size();i++){
            Student s= array.get(i);
            if (s.getSid().equals(sid)){
                flag=true;
                break;
            }
        }

        return flag;

    }

}
