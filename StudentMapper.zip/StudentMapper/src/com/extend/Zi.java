package com.extend;

public class Zi extends Fu {
    public void method(){
        System.out.println("Zi中method()");
    }
    public void show(){
        super.show();
        System.out.println("Zi中show()方法被调用");
    }

//    //年龄
//    public int age =20;
////    //身高
////    public int height =173;
//    public void show(){
//        int age=30;//现在子类方法中寻找，再去本子类，再去父类，如果都没有就报错
//        //我要访问局部变量的age
//        System.out.println(age);
//        //我要访问本类的成员变量age
//        //this：代表本类对象的引用
//        System.out.println(this.age);
//        //我要访问父类的成员变量age
//        //super：代表父类存储空间的标识（可以理解为父类对象调用）
//        System.out.println(super.age);
////        System.out.println(height);
//        //报错
////        System.out.println(weight);
//}
//    public Zi(){
////        super();
//        super(20);
//        System.out.println("Zi中无参构造方法被调用");
//    }
//    public Zi(int age){
////        super();
//        super(20);
//        System.out.println("Zi中带参构造方法被调用");
//    }
}
