package com.extend;

/*
测试类
继承的格式： public class 子类名 extends 父类名{}
          范例： public class Zi extends Fu{}
          Fu:是父类，也称为基类，超类
          Zi：是子类，也称为派生类
     子类可以有父类的内容
     也可以有自己特有的内容
子类中所有的构造方法默认都会访问父类中无参的构造方法
因为子类会继承父类中的数据，可能还会使用父类的数据，所以子类初始化之前，一定要先完成父类的初始化
每一个子类构造方法的第一条语句默认都是：super()   supers 调用父类 （）括号为空则为无参构造
*/
public class Demo {
    public static void main(String[] args) {
        //创建对象，调用方法

        Zi z=new Zi();

        z.method();
        z.show();
        //报错
//        z.test();
//        Zi z2=new Zi(20);
    }
}
