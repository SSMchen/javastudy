package com.extend;

public class Fu {
//    //年龄
//    public int age =40;
//
//    public Fu(){
//        System.out.println("Fu中无参构造方法被调用");
//    }
    public void show(){
        System.out.println("Fu中show()方法被调用");
    }
}
