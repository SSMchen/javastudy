package com.Animals;
/*
    2.定义猫类（Cat），继承动物类
          构造方法:无参，带参
          成员方法:抓老鼠（）
     */
public class Cat extends Animal{
    public Cat (String name,int age){
        super(name,age);
    }
    public Cat (){}
    public void mouse(){
        System.out.println("我是猫，我会抓老鼠");
    }
}
