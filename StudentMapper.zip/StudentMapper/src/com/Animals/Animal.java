package com.Animals;
/*  分析：
1.猫，  成员变量： 姓名，年龄
       构造方法： 无参，带参
       成员方法： get/set方法，抓老鼠（）
2.狗，  成员变量： 姓名，年龄
       构造方法： 无参，带参
       成员方法：get/set方法，看门（）
3.共性：
        成员变量：姓名，年末领；
        构造方法：无参，带参
        成员方法：get/set方法
 */
public class Animal {
    /*
    1.定义动物类（Animal）
          成员变量:姓名，年龄
          构造方法:无参，带参
          成员方法:get/set方法
     */
    private String name;
    private int age;
    public Animal(){

    }
    public Animal(String name,int age){
        this.name=name;
        this.age=age;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
}
