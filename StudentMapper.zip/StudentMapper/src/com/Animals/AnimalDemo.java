package com.Animals;
/*
    定义测试类AnimalDemo，写代码测试
     */
public class AnimalDemo {
    public static void main(String[] args) {
        //创建猫类对象并进行测试

        Cat c= new Cat();
        c.setName("咖啡猫");
        c.setAge(2);
        System.out.println(c.getName()+","+c.getAge());
        c.mouse();

        //带参
        Cat c1 = new Cat("Canada",5);
        System.out.println(c1.getName()+","+c1.getAge());
        c1.mouse();

        //创建狗类对象并进行测试
        Dog d = new Dog();
        d.setName("汪汪");
        d.setAge(3);
        System.out.println(d.getName()+","+d.getAge());
        d.door();

        Dog d1 = new Dog("灿灿",1);
        System.out.println(d1.getName()+","+d1.getAge());
        d1.door();

    }
}
