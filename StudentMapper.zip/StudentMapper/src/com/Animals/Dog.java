package com.Animals;
/*
   3.定义狗类（Dog），继承动物类
         构造方法:无参，带参
         成员方法:看门（）
    */
public class Dog extends Animal {
    public Dog(){}
    public Dog(String name,int age){
        super(name,age);
    }
    public void door(){
        System.out.println("我是狗，我会看门");
    }
}
