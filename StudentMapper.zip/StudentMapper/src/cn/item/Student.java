package cn.item;

public class Student {
    public int age = 20;
}
