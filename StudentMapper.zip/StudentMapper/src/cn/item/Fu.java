package cn.item;

public class Fu {
    private void show(){
        //只能在本类中被访问
        System.out.println("private");
    }
    //在同一个包内的不同类也可以访问以下三种方式定义的方法
    void show2(){
        System.out.println("默认");
    }
    protected void show3(){
        System.out.println("protected");
    }
    public void show4(){
        System.out.println("public");
    }
    public static void main(String[] args){
        //创建Fu的对象，测试看哪些方法可以使用
        Fu f=new Fu();
        f.show();
        f.show2();
        f.show3();
        f.show4();

    }
}
