package cn.item;

public class Demo {
    //创建Fu的对象，测试看有哪些方法可以使用
    public static void main(String[] args) {
        Fu f = new Fu();
        f.show2();
        f.show4();
        f.show3();
    }

}
