package cn.item;

public class FinalDemo {
    public static void main(String[] args) {
        //final修饰基本类型变量  数据值不能变
        final int age =120;
//        age =100;
        System.out.println(age);

        //final修饰引用类型变量   地址值不能变，数据值可以变
        final Student s = new Student();
        s.age=100;
        System.out.println(s.age);
    }
}
