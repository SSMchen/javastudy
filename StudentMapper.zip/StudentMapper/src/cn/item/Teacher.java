package cn.item;

public class Teacher {
    public void teach(){
        System.out.println("教师名言：桃李满天下");
    }
}
