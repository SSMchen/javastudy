package JiaoLian;
/*
乒乓球运动员具体类
 */
public class PingPangPlayer extends Player implements Speaking{
    public PingPangPlayer(String name, int age) {
        super(name, age);
    }

    public PingPangPlayer() {
    }

    @Override
    public void speak() {
        System.out.println("乒乓球运动员说英语");
    }

    @Override
    public void eat() {
        System.out.println("乒乓球运动员吃大白菜");
    }

    @Override
    public void study() {
        System.out.println("乒乓球运动员学习如何发球和接球");
    }
}
