package JiaoLian;

public abstract interface Speaking {
    public abstract void speak();
}
