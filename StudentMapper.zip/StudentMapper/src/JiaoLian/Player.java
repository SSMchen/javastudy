package JiaoLian;
/*
抽象运动员类
 */
public abstract class Player extends Person {
    public Player(String name, int age) {
        super(name, age);
    }

    public Player() {
    }
    public abstract void study();
}
