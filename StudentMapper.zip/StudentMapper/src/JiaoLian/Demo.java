package JiaoLian;
/*
测试类
 */
public class Demo {
    public static void main(String[] args) {
        //创建对象
        PingPangPlayer pp= new PingPangPlayer();
        pp.setName("王浩");
        pp.setAge(30);
        System.out.println(pp.getName()+","+pp.getAge());
        pp.eat();
        pp.study();
        pp.speak();
        System.out.println("----------");
       BasketballPlayer bp= new BasketballPlayer();
        bp.setName("li浩");
        bp.setAge(15);
        System.out.println(bp.getName()+","+bp.getAge());
        bp.eat();
        bp.study();
//        bp.speak();
    }
}
