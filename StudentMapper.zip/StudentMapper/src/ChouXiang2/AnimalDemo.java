package ChouXiang2;
/*
测试类
 */
public class AnimalDemo {
    public static void main(String[] args) {
        //创建对象，按照多态的方式
        Animal a= new Cat();
        a.setName("小软");
        a.setAge(5);
        System.out.println(a.getName()+","+a.getAge());
        a.eat();

        a= new Cat("小白",6);
        System.out.println(a.getName()+","+a.getAge());
        a.eat();
    }
}
