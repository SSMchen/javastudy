package ChouXiang;
/*
抽象类
必须使用abstract关键字

抽象类中不一定有抽象方法，有抽象方法的类一定是抽象类

抽象类不能实例化，参照多态的方式，通过子类对象实例化，这叫抽象类多态

抽象类子类   要么重写抽象类中的抽象方法，要么子类也是抽象类
 */
/*
抽象类的成员特点
    成员变量：
        可以是变量
        也可以是常量
    构造方法：
        有构造方法，但是不能实例化
        用于子类访问父类数据的初始化
    成员方法:
        可以有抽象方法：限定子类必须完成某些动作
        也可以用非抽象方法：提高代码复用性
 */
public abstract class Animal {
//    /*public void eat(){
//        System.out.println("吃东西");
//    }
//     */
//   // 抽象方法   抽象类中可以没有抽象方法
//    public abstract void eat();
//    //抽象类中也可以写具体类
//    public void sleep(){
//        System.out.println("睡觉");
//    }
    private int age = 20;
    private final String city="北京";
    public Animal(){};
    public Animal(int age){
        this.age=age;
    }
    public void show(){
        age=40;
//        city="上海";
        System.out.println(age);
        System.out.println(city);
    }
    public abstract void eat();
}
