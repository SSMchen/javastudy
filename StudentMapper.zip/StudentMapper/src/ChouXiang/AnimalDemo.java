package ChouXiang;

public class AnimalDemo {
    public static void main(String[] args) {
//        /*
//        Animal a = new Animal();
//        a.eat();
//         */
//        Animal a = new Cat() ;
//        a.eat();
//        a.sleep();a
        Animal a = new Cat();
        a.eat();
        a.show();
    }
}
