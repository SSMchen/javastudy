package ChouXiang;
//抽象类子类   要么重写抽象类中的抽象方法，要么子类也是抽象类
public class Cat extends Animal{
    @Override
    public void eat() {
        System.out.println("猫吃鱼");
    }
}
