package mc.test;

public class Student {
    public String name;
    public int age;
    //public String university;
    public static String university;//static 共享成员变量给所有对象
    public void  show(){
        System.out.println(name+","+age+","+university);
    }
}
