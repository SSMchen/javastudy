package mc.test;

import cn.item.Fu;
//不同包下有关类
public class Zi  extends Fu {
    public static void main(String[] args) {
        //创建Zi的对象，测试看有哪些方法可以使用
        Zi z=new Zi();
        z.show4();
        z.show3();
    }
}
