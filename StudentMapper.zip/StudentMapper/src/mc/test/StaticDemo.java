package mc.test;
/*
测试类
 */
public class StaticDemo {
    public static void main(String[] args) {
        Student.university="beijing ";//推荐使用类名调用
        Student s1 = new Student();
        s1.name="钱钱钱";
        s1.age=1;
//        s1.university="北京";
        s1.show();

        Student s2 = new Student();
        s2.name="挣钱挣钱";
        s2.age=20000;
//        s2.university="北京";
        s2.show();
    }
}
