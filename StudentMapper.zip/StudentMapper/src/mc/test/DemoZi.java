package mc.test;

import cn.item.Fu;

//不同包下无关类
public class DemoZi {
    public static void main(String[] args) {
        Fu f = new Fu();
        f.show4();
    }
}
