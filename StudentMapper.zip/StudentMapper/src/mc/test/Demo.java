package mc.test;


import cn.item.Teacher;

public class Demo {
    public static void main(String[] args) {
        //cn.item.Teacher t= new  cn.item.Teacher();
        Teacher t = new Teacher();
        t.teach();


    }
}
