package fanxing;

public class A11 {
    public static void main(String[] args) {
//        A1 a= new A1();
//        a.show("林青霞");
//        a.show(30);
//        a.show(true);
//        a.show(12.34);   报错因为在方法中没有对应
        A1  a = new A1();
        a.show("凌青霞");
        a.show(30);
        a.show(true);
        a.show(13.23);

    }
}
