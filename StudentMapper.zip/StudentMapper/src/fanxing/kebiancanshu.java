package fanxing;

import java.util.Arrays;
import java.util.List;
import java.util.Set;

/*
Arrays工具类中有一个静态方法：

        - public static<T>List<T> asList(T...a):返回由指定数组支持的固定大小的列表

 List接口中有一个静态方法：

        - public static <E>List<E> of (E...elements):返回包含任意数量元素的不可变列表

 Set接口中有一个静态方法：

        - public static<E>Set<E> of(E...elements):返回一个包含任意数量元素的不可变集合

 */
public class kebiancanshu {
    public static void main(String[] args) {
//        System.out.println(sum(10,20));
//        System.out.println(sum(10,20,30));
//        System.out.println(sum(10,20,30,40));
//
//        System.out.println(sum(10,20,30,40,50));
//        System.out.println(sum(10,20,30,40,50,60));
//        System.out.println(sum(10,20,30,40,50,60,70));
//        System.out.println(sum(10,20,30,40,50,60,70,80,90,100));//也可以
//  - public static<T>List<T> asList(T...a):返回由指定数组支持的固定大小的列表
//        List<String> list = Arrays.asList("hello", "world", "java");
////        list.add("javaee");//UnsupportedOperationException  不支持请求的操作
////        list.remove("world");//UnsupportedOperationException  不支持请求的操作
//        list.set(1,"javaee");//可以
//        System.out.println(list);
/*
        List<String> list = List.of("hello","world","java");//list 可以重复
        list.add("javaee");//UnsupportedOperationException  不支持请求的操作
        list.remove("java");//UnsupportedOperationException  不支持请求的操作
        list.set(1,"javaee");//UnsupportedOperationException  不支持请求的操作
        System.out.println(list);
       //of是JDK9的新特性

 */
//        Set<String> set  = Set.of("hello","world","java");//如果有重复元素报 ILLegaLArgumentExceptior错误： 非法或者不正确的参数
//        set.add("javaee");//UnsupportedOperationException  不支持请求的操作
//        set.remove("java");//UnsupportedOperationException  不支持请求的操作
//
//        System.out.println(set);
    }
//    public static int sum(int...a ){//a 是个数组 将方法调用中的参数 封装到这个数组中
//        int sum = 0 ;
//        for(int i: a){
//            sum+=i;
//        }
//        return sum;
//    }
    /*
    public static int sum(int b,int...a ){   一个方法包含多个参数时可变参数要放在后面
        return sum;
    }
     */
//    public static int sum(int a ,int b){
//        return a+b;
//    }
//    public static int sum(int a ,int b,int c){
//        return a+b+c;
//    }
//    public static int sum(int a ,int b,int c,int d){
//        return a+b+c+d;
//    }

}
