package fanxing;

public class A21Impl<T> implements A21<T> {
    @Override
    public void show(T t) {
        System.out.println(t);
    }
}
