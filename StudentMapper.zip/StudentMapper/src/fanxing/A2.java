package fanxing;

public class A2 {
    public static void main(String[] args) {
        A21<String> a = new A21Impl<String>();
        a.show("林青霞");
        A21<Integer> a1 = new A21Impl<Integer>();
        a1.show(60);

    }
}
