package fanxing;

public interface A21<T> {
    void show(T t);//不能直接使用，接口不能实例化     所以应给给出实现类

}
