package fanxing;

import java.util.ArrayList;
import java.util.List;

public class tongpeifu {
    public static void main(String[] args) {
        //类型通配符：<?>
        List<?> list1 = new ArrayList<Object>();
        List<?> list2 = new ArrayList<Number>();
        List<?> list3 = new ArrayList<Integer>();
        //可以表示任意类型的List集合
        //类型通配符的上限
       //object 在number的上面，number是上限所以不能比number高
        // List<? extends Number> list4 = new ArrayList<Object>();
        List<? extends Number> list5 = new ArrayList<Number>();
        List<? extends Number> list6= new ArrayList<Integer>();
        //类型通配符的下限
        //integer是number的子类型，number是下限所以不能比number小
        List<? super Number> list7 = new ArrayList<Object>();
        List<? super Number> list8 = new ArrayList<Number>();
       // List<? super Number> list9= new ArrayList<Integer>();
    }
}
