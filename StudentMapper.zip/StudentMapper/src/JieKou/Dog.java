package JieKou;
//抽象类在实现接口时可以不重写接口中的方法
public abstract class Dog implements Jumpping{
//    @Override
//    public void jump() {
//        System.out.println("狗会跳高了");
//    }

}
