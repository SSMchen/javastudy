package JieKou;
/*
定义了一个接口
 */
public interface Jumpping {
    public abstract void jump();
}
