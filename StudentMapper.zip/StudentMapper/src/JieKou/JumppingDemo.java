package JieKou;
/*
接口关键字：interface
类实现接口用:implements
接口不能实例化，也是参照多态的方式，通过实现类对象的实例化，这叫接口多态
多态的形式： （具体类多态）、抽象类多态、接口多态
多态的前提： 有继承或者实现关系；有方法重写；有父（类/接口）引用指向（子/实现）类对象
接口类的实现：要么重写接口中的所有抽象方法，要么是抽象类
 */
public class JumppingDemo {
    public static void main(String[] args) {
//        Jumpping j = new Jumpping();接口也是抽象的
        Jumpping j = new Cat();
        j.jump();
    }
}
