package JieKou;

public interface Inter {
    public int num=10;
    public final int num2= 20;

//    public Inter(){  接口是没有构造方法的}
//    public void show(){}     抽象方法不能有方法体    接口里面不能有抽象方法
     public abstract void method();
     void show();//接口里的方法默认带有 public abstract 修饰符
}
