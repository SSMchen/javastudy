import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
/*
public Date()  :分配一个Date对象，并初始化，以便代表她被分配的时间，精确到毫秒
public Date(long date) 分配一个Date对象，并将其初始化为表示从标准基准时间起指定的毫秒数
 */
/*
public long getTime():获取的是日期对象从1970.01.01 00:00:00到现在的毫秒值
public void setTime(long time):设置时间。给的是毫秒值
 */
//public class DateTest {
//    public static void main(String[] args) throws ParseException {
//        //public Date()  :分配一个Date对象，并初始化，以便代表她被分配的时间，精确到毫秒
//        Date d1= new Date();
//        System.out.println(d1);
//        //public Date(long date) 分配一个Date对象，并将其初始化为表示从标准基准时间起指定的毫秒数
//        long date = 1000*60*60;
//        Date d2 = new Date(date);
//        System.out.println(d2);
//        //创建日期对象
//        Date d = new Date();
//        //public long getTime():获取的是日期对象从1970.01.01 00:00:00到现在的毫秒值
//        System.out.println(d.getTime());
//        System.out.println(d.getTime()*1.0/1000/60/60/24/365+"年");
//        //public void setTime(long time):设置时间。给的是毫秒值
//        long time = 1000*60*60;
//        long time1= System.currentTimeMillis();
//        d.setTime(time);
//        System.out.println(d);
        //格式化（从Date到String）
//        Date d = new Date();//日期
        //SimpleDateFormat sdf = new SimpleDateFormat();//通过SimpleDateFormat的sdf对象
        //SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
//        SimpleDateFormat sdf = new SimpleDateFormat("yyyy年MM月dd日HH:mm:ss");
//        String s = sdf.format(d);//调用format方法将日期型d格式化为字符串型s
//        System.out.println(s);
//        //解析（从String到Date）
//        String ss="2022-02-22 22:22:22";//字符串要与下面的模式格式一致
//        SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//        Date dd = sdf1.parse(ss);
//        System.out.println(dd);//.ParseException解析异常
//    }
//}
/*
需求：定义一个日期工具类（dateUtils），
包含两个方法：把日期转换为指定格式的字符串；把字符串解析为指定格式的日期
然后定义一个测试类（DateDemo），测试日期工具类的方法
思路：
1.定义日期工具类（DateUtils）
2.定义一个方法dateToString，用于把日期转换为指定格式的字符串
    返回值类型：String
    参数：Date date，String format
3.定义一个方法stringToDate，用于字符串解析为指定格式的日期
    返回值类型：Date
    参数：String s，String format
4.定义测试类DateDemo，调用日期工具类中的方法
 */

public class DateTest {
/*
工具类：构造方法私有|成员方法静态
 */
    private DateTest(){}
    /*
    把日期转为指定格式的字符串
    返回值类型：String
    参数：Date date，String format
     */
    //成员方法用静态修饰：将来通过类名调用，返回值为String
    public static String dateToString(Date date,String format){
        SimpleDateFormat sdf = new SimpleDateFormat(format);//按照指定格式创建SimpleDateFormat
        String s = sdf.format(date);//用sdf对象调用format方法把日期转换为了指定格式的字符串传给s
        return s;//返回s
    }
    /*
    用于字符串解析为指定格式的日期
    返回值类型：Date
    参数：String s，String format
     */
    public static Date stringToDate(String s, String format) throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat(format);
        Date d = sdf.parse(s);
        return d;
    }
}