package CollectionDemo;

import java.util.Comparator;
import java.util.TreeSet;

public class Achievement {
    public static void main(String[] args) {
        //创建TreeSet集合对象，通过比较器排序进行排序
        TreeSet<AchievementStudent> st =new TreeSet<AchievementStudent>(new Comparator<AchievementStudent>() {
            @Override
            public int compare(AchievementStudent s1,AchievementStudent s2) {
//                 int num= (s2.getChinese()+s2.getMath())-(s1.getMath()+s1.getChinese());
                //主要条件
                int num = s2.getSum()-s1.getSum();
                //次要条件
                int num2=num==0?s1.getMath()-s2.getMath():num;
                int num3=num==0?s1.getName().compareTo(s2.getName()):num;
                return  num3;
            }
        });
        //创建学生对象
        AchievementStudent s1 = new AchievementStudent("小王",90,60);
        AchievementStudent s2 = new AchievementStudent("小李",70,80);
        AchievementStudent s3 = new AchievementStudent("小黄",55,60);
        AchievementStudent s4 = new AchievementStudent("小孟",99,90);
        AchievementStudent s5 = new AchievementStudent("小聂",98,92);

        AchievementStudent s6 = new AchievementStudent("小ba",98,92);
        //添加学生对象
        st.add(s1);
        st.add(s2);
        st.add(s3);
        st.add(s4);
        st.add(s5);
        st.add(s6);
        //遍历
        for (AchievementStudent s : st){
            System.out.println(s.getName()+','+s.getChinese()+","+s.getMath()+","+s.getSum());
        }
    }
}
