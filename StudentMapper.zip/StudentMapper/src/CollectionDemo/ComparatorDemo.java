package CollectionDemo;

import java.util.Comparator;
import java.util.TreeSet;

public class ComparatorDemo {
    public static void main(String[] args) {
        //创建集合对象
        TreeSet<ComparatorStudent> ts = new TreeSet<ComparatorStudent>(new Comparator<ComparatorStudent>() {

            @Override
            public int compare(ComparatorStudent s1,ComparatorStudent s2) {
                //this.age-s.age
                //不能访问学生类的私有成员
                int num = s1.getAge()- s2.getAge();
                int num2=num==0?s1.getName().compareTo(s2.getName()):num;

                return num2;
                //tish带的是ComparatorDemo而不是学生   所以参数传递的是两个学生对象

            }
        });
        //创建学生对象
        ComparatorStudent s1 = new ComparatorStudent("西施",49);
        ComparatorStudent s2 = new ComparatorStudent("王昭君",36);
        ComparatorStudent s3 = new ComparatorStudent("貂蝉",49);
        ComparatorStudent s4 = new ComparatorStudent("杨玉环",33);
        //把学生添加到集合
        ts.add(s1);
        ts.add(s2);
        ts.add(s3);
        ts.add(s4);

        //遍历集合
        for (ComparatorStudent  s: ts){
            System.out.println(s.getName()+','+s.getAge());
        }
        //ClassCastException类转换异常
        //CollectionDemo.Student cannot be cast to java.lang.Comparable


    }
}
