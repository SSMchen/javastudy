package CollectionDemo;

import java.util.TreeSet;

public class TreeSetDemo {

    public static void main(String[] args) {
        //创建TreeSet集合对象
        TreeSet<Student> ts= new TreeSet<Student>();//无参构造
        //创建学生对象
        Student s1 = new Student("西施",49);
        Student s2 = new Student("王昭君",36);
        Student s3 = new Student("貂蝉",49);
        Student s4 = new Student("杨玉环",33);
        //把学生添加到集合
        ts.add(s1);
        ts.add(s2);
        ts.add(s3);
        ts.add(s4);

        //遍历集合
        for (Student  s: ts){
            System.out.println(s.getName()+','+s.getAge());
        }
        //ClassCastException类转换异常
        //CollectionDemo.Student cannot be cast to java.lang.Comparable

    }


}
