package CollectionDemo;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;

public class ListDemo {
    public static void main(String[] args) {
        //创建集合对象
        ArrayList<String> array = new ArrayList<String>();

        array.add("hello");
        array.add("world");
        array.add("java");

        //遍历
        for (String s : array){
            System.out.println(s);
        }
        Iterator<String> it = array.iterator();
        while (it.hasNext()){
            String s = it.next();
            System.out.println(s);
        }
        for (int i= 0 ;i<array.size();i++){
            String s = array.get(i);
            System.out.println(s);
        }
        LinkedList<String> linkedList = new LinkedList<String>();
        linkedList.add("ok");
        linkedList.add("yes");
        linkedList.add("no");
        //遍历
        for (String o : linkedList){
            System.out.println(o);
        }
        Iterator<String> li = linkedList.iterator();
        while (li.hasNext()){
            String o =li.next();
            System.out.println(o);
        }
        for (int i= 0 ;i<linkedList.size();i++){
            String o = linkedList.get(i);
            System.out.println(o);
        }
    }
}
