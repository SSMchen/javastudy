package CollectionDemo;

import java.util.LinkedHashSet;
import java.util.TreeSet;

public class LinkedHashSetDemo {
    public static void main(String[] args) {
//        //创建对象
//        LinkedHashSet<String> linkhs = new LinkedHashSet<String>();
//
//        linkhs.add("hello");
//        linkhs.add("world");
//        linkhs.add("java");
//        linkhs.add("hello");
//        //建立集合
//        for(String s : linkhs){
//            System.out.println(s);
//        }
        //创建集合对象
        //在基本类型存储是使用的是其对应的包装类类型
        TreeSet<Integer> ts = new TreeSet<Integer>();
        //采用的无参构造方法，会根据自然排序进行排序
        //添加元素    jdk5之后可以自动装箱
        ts.add(10);
        ts.add(40);
        ts.add(30);
        ts.add(50);
        ts.add(20);

        //遍历集合
        for (Integer i :ts){
            System.out.println(i);
        }
    }
}
