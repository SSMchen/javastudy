package CollectionDemo;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

/*
案例：创建一个存储学生对象的集合，存储3个学生对象，使用程序实现在控制台遍历该集合

思路：

 	1. 定义学生类
 	2. 创建list集合对象
 	3. 创建学生对象
 	4. 把学生添加到集合
 	5. 遍历集合（迭代器方式，for循环方式）
 */
public class ListStudentDemo {
    public static void main(String[] args) {
        //2. 创建list集合对象
        List<Student> list = new ArrayList<Student>();
        //3. 创建学生对象
        Student s1 = new Student("林青霞",30);
        Student s2 = new Student("王八蛋",3);
        Student s3 = new Student("小乌龟",15);
        //4. 把学生添加到集合
        list.add(s1);
        list.add(s2);
        list.add(s3);
        //迭代器方式   迭代器：集合特有的遍历方式
        Iterator<Student> it = list.iterator();
        while (it.hasNext()){
            Student s = it.next();
            System.out.println(s.getName()+','+s.getAge());
        }
        System.out.println("---------");
        //for循环方式  普通for：带有索引的遍历方式
        for (int i=0;i< list.size();i++){
            Student s = list.get(i);
            System.out.println(s.getName()+','+s.getAge());
        }
        //增强for：最方便的遍历方式
        for (Student s:list){
            System.out.println(s.getName()+','+s.getAge());
        }
//        List<String> l = new ArrayList<>();
//        l.add("hello");
//        l.add("world");
//        l.add("java");
//        //获取列表迭代器
//        ListIterator<String> lit = l.listIterator();
//        while (lit.hasNext()){
//            String s = lit.next();
//            if (s.equals("world")){
//                lit.add("javaee");
//            }
//        }
//        System.out.println(l);
////通过list集合的listIterator（）方法得到
//        //正向遍历   会直接 使用Iterator
//        ListIterator<String> lit = l.listIterator();
//        while (lit.hasNext()){
//            String s = lit.next();
//            System.out.println(s);
//        }
//        System.out.println("--------");
//        //逆向遍历(了解)
//        while (lit.hasPrevious()){
//            String m = lit.previous();
//            System.out.println(m);
//        }
        //遍历集合，得到每一个元素，看有没有'word'这个元素，如果有，我就添加Javaee
//        Iterator<String> it = l.iterator();
//        while (it.hasNext()){
//            String s = it.next();
//            if (s.equals("world")){
//                l.add("javaee");
//            }
//        }
//        for(int i=0;i<l.size();i++){
//            String s = l.get(i);
//            if (s.equals("world")){
//                l.add("javaee");
//            }
//
//        }
//        System.out.println(l);

    }

}
