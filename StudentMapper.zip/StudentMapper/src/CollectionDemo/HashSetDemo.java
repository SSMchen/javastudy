package CollectionDemo;

import java.util.HashSet;

public class HashSetDemo {
    public static void main(String[] args) {
        //2.创建HashSet集合对象
        HashSet<Student> hs = new HashSet<Student>();

        //3.创建学生对象
        Student s1 = new Student("java",20);
        Student s2 = new Student("HTML",30);
        Student s3 = new Student("python",25);
        Student s4 = new Student("python",25);


        //4.把学生添加到集合
        hs.add(s1);
        hs.add(s2);
        hs.add(s3);
        hs.add(s4);
        //5.遍历集合（增强for）
        for (Student s: hs){
            System.out.println(s.getName()+","+s.getAge());
        }
    }
}
