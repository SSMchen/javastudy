package CollectionDemo;

import java.util.ArrayList;
import java.util.Collection;
/*
创建Collection集合的对象
    多态的方式
    ArrayList()
 */

public class CollectionDemo {
    public static void main(String[] args) {
        //创建Collection集合的对象
        Collection<String> c= new ArrayList<String>();//ArrayList重写了toString方法
        //添加元素： boolean add（E e）可重复
//        System.out.println(c.add("hello")); //true
//                                            //[hello]
//        System.out.println(c.add("world")); //true
//                                            //true
//                                            //[hello, world]
//        System.out.println(c.add("world")); //true
//                                            //true
//                                            //true
//                                            //[hello, world, world]
//       alt+7 打开一个窗口，能够看到类的所有信息
        c.add("hello");
        c.add("world");
        c.add("Java");
//add--boolean
//remove--boolean
        System.out.println(c.remove("world"));//true
        System.out.println(c.remove("javaee"));//false,元素不存在
//clear--void
        c.clear();
// contains--boolean
        System.out.println(c.contains("world"));//true
        System.out.println(c.contains("javaee"));//false,元素不存在
//isEmpty--boolean
        System.out.println(c.isEmpty());
//size--int
        System.out.println(c.size());

        //输出集合对象
        System.out.println(c);
    }
}
