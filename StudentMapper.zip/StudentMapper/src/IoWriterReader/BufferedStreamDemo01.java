package IoWriterReader;

import java.io.*;

/*
BufferedReader :从字符输入流读取文本，缓冲字符，以提供字符，数组和行的高效读取。
BufferedWriter :将文本写入字符输出流，缓冲字符，以提供单个字符，数组和字符串的高效写入。

构造方法：
    BufferedReader(Reader in)
    BufferedWriter(Writer out)
 */
public class BufferedStreamDemo01 {
    public static void main(String[] args) throws IOException {
            //BufferedWriter(Writer out)
//        FileWriter fw = new FileWriter("bw.txt");
//        BufferedWriter bw = new BufferedWriter(fw);
        BufferedWriter bw = new BufferedWriter(new FileWriter("bw.txt"));
        bw.write("hello\r\n");
        bw.write("world");
        bw.write("slo");
        bw.close();
        //BufferedReader(Reader in)
        BufferedReader br =new BufferedReader( new FileReader("bw.txt"));
        //读数据的两种方法
        //一次读取一个字符数据
        int ch ;
        while ((ch=br.read())!=-1){
            System.out.print((char)ch);
        }
        BufferedReader bs =new BufferedReader( new FileReader("bw.txt"));
        //一次读一个字符数组
        char[] chs = new char[1024];
        int len;
        while ((len=bs.read(chs))!=-1){
            System.out.print(new String(chs,0,len));
        }

    }
}
