package IoWriterReader;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

/*
需求：我有一个文件里面存储了班级同学的姓名，每一个姓名占一行，要求通过程序实现随机点名器

(每一次运行程序，则每一次在控制台输出一个人的名字，就是把文件里的名字放到集合中去，ArrayList集合中是有索引的，所以需要随机产生一个索引，索引的范围是在文件长度的范围内。然后根据索引输出姓名)

思路：

1. 创建字符缓冲输入流对象
2. 创建ArrayList集合对象
3. 调用字符缓冲输入流对象的方法读数据
4. 把读取到的字符串数据存储到集合中
5. 释放资源
6. 使用Random产生一个随机数，随机数的范围在：[0,集合的长度)
7. 把第6步产生的随机数作为索引到ArrayList集合中获取值
8. 把第七步得到的数据输出在控制台
 */
public class CallNameDemo {
    public static void main(String[] args) throws IOException {
        //1. 创建字符缓冲输入流对象
        BufferedReader br = new BufferedReader(new FileReader("names.txt"));
        //2. 创建ArrayList集合对象
        ArrayList<String> array = new ArrayList<String>();
        //3. 调用字符缓冲输入流对象的方法读数据
        String line;
        while ((line = br.readLine())!=null){
            //4. 把读取到的字符串数据存储到集合中
            array.add(line);
        }
        //5. 释放资源
        br.close();
        //6. 使用Random产生一个随机数，随机数的范围在：[0,集合的长度)
        Random r = new Random();
        int index = r.nextInt(array.size());
        //7. 把第6步产生的随机数作为索引到ArrayList集合中获取值
        String name = array.get(index);
        //8. 把第七步得到的数据输出在控制台
        System.out.println(name);
    }
}
