package IoWriterReader;

import java.io.*;

/*
BufferedWriter:
    void newLine():写一个行分隔符，行分隔符字符串由系统属性定义
BufferedReader:
    public String readLine():读一行文字。结果包含行的内容的字符
 */
public class BufferedStreamDemo02 {
    public static void main(String[] args) throws IOException {
        /*
        //创建字符缓冲输出流
        BufferedWriter bw = new BufferedWriter(new FileWriter("bw.txt"));
        //写数据
        for (int i = 0;i<10;i++){
            bw.write("hello"+i);
//            bw.write("\r\n");
            bw.newLine();
            bw.flush();
        }
        //释放资源
        bw.close();
         */
        //创建字缓冲输入流
        BufferedReader br = new BufferedReader(new FileReader("bw.txt"));
        /*
        //第一次读取数据
        String line = br.readLine();
        System.out.println(line);
        //第二次读取数据
        line= br.readLine();
        System.out.println(line);
        //3
        line= br.readLine();
        System.out.println(line);
        //4
        line= br.readLine();
        System.out.println(line);
         */
        //采用循环
        String line;
        while ((line=br.readLine())!=null){
            System.out.println(line);
        }
    br.close();
    }
}
