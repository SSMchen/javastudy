package DuoTai2;
/*
测试类
 */
public class AnimalDemo {
    public static void main(String[] args) {
        //1创建猫类对象进行测试
        Animal a = new Cat();
        a.setName("咖啡");
        a.setAge(2);
        System.out.println(a.getName()+","+a.getAge());
        a.eat();

        a= new Cat("coffe",6);
        System.out.println(a.getName()+","+a.getAge());
        a.eat();
        //1创建gou类对象进行测试
        Animal s = new Dog();
        s.setName("朱金朋");
        s.setAge(2);
        System.out.println(s.getName()+","+s.getAge());
        s.eat();

        s= new Dog("月月",6);
        System.out.println(s.getName()+","+s.getAge());
        s.eat();
    }

}
