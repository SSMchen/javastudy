package JieKouAnimal;

public class AnimalDemo {
    public static void main(String[] args) {
        //创建对象，调用方法
        Jumpping j = new Cat();
        j.jump();
        System.out.println("--------");
        Animal a = new Cat();
        a.setName("咖咖");
        a.setAge(5);
        System.out.println(a.getName()+","+a.getAge());
        a.eat();

        a= new Cat("咖咖卡",5);
        System.out.println(a.getName()+","+a.getAge());
        a.eat();

        Cat c = new Cat();
        c.setName("咖2咖");
        c.setAge(3);
        System.out.println(c.getName()+","+c.getAge());
        c.eat();
        c.jump();
    }
}
