package JieKouAnimal;

public interface Jumpping {
    public abstract void jump();
}
