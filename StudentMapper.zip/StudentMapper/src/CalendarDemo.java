import java.util.Calendar;

//Calendar为某一时刻和一组日历字段之间的转换提供了一些方法。并为操作日历字段提供了一些方法
//Calendar提供了一个类方法getInstance用于获取Calendar对象，其日历字段已使用当前日期和时间初始化：
/*
public abstract void add(int field,int amount);根据日历的规则，将指定的时间量添加或减去给定的日历字段
public final void set(int year,int month,int date);设置当前日历的年月日

 */
public class CalendarDemo {
        public static void main(String[] args){
                //获取对象
                Calendar ca = Calendar.getInstance();//多态形式得到对象：一个返回值类型，是一个抽象类，那么他需要的是该类的子类对象
//                System.out.println(ca);
                //public int get (int field)   通过给定的日历字段得出日历字段的值
//                int year = ca.get(Calendar.YEAR);
//                int month = ca.get(Calendar.MONTH) + 1;
//                int date = ca.get(Calendar.DATE);
//                System.out.println(year+"年"+month+"月"+date+"日");
//                public abstract void add(int field,int amount);根据日历的规则，将指定的时间量添加或减去给定的日历字段
                //需求二，三年前的今天
//                ca.add(Calendar.YEAR,-3);
//                int year1 = ca.get(Calendar.YEAR);
//                int month1 = ca.get(Calendar.MONTH) + 1;
//                int date1 = ca.get(Calendar.DATE);
//                System.out.println(year1+"年"+month1+"月"+date1+"日");
//                //需求三，十年后的五天前
//                ca.add(Calendar.YEAR,10);
//                ca.add(Calendar.DATE,-5);
//                int year2 = ca.get(Calendar.YEAR);
//                int month2 = ca.get(Calendar.MONTH) + 1;
//                int date2 = ca.get(Calendar.DATE);
//                System.out.println(year2+"年"+month2+"月"+date2+"日");
                //public final void set(int year,int month,int date);设置当前日历的年月日
                ca.set(2022,01,22);
                int year = ca.get(Calendar.YEAR);
                int month = ca.get(Calendar.MONTH) + 1;
                int date = ca.get(Calendar.DATE);
                System.out.println(year+"年"+month+"月"+date+"日");
        }
}
