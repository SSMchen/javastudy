package ScoreException;

import java.util.Scanner;

//测试一下
public class TDScoreException {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("请输入分数");
        int score = sc.nextInt();

        DScoreException d= new DScoreException();
        try {
            d.checkScore(score);
        } catch (ScoreException e) {
            e.printStackTrace();
        }


    }
}
