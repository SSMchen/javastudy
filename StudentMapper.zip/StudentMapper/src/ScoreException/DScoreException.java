package ScoreException;

public class DScoreException {
    public void checkScore(int score) throws ScoreException {
        if (score<0 || score>100){
//            throw new ScoreException();//用来在方法体内部抛出异常对象
            //ScoreException继承自Exception 所以在 上面用throws把异常类抛出（编译时期异常）
            throw new ScoreException("你给的分数应该在0-100之间");
        }else{
            System.out.println("分数正常");
        }
    }
}
