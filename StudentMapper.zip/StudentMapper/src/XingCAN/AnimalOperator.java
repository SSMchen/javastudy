package XingCAN;

public class AnimalOperator {
    public void useAnimal(Animal a){//animal a = new Cat();
        a.eat();
    }
}
