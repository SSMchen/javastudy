package XingCAN;

public abstract class Animal {//多态形式创建抽象类的子类对象，
    // （在子类中重写抽象类中的方法）用来传递。
    // 需要的是该类的子类对象

//    public void eat(){
//        System.out.println("狗吃肉");
//    }
    public abstract void eat();//多态形式创建抽象类的子类对象，（在子类中重写抽象类中的方法）用来传递。//需要的是该类的子类对象
}
