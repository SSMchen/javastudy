package XingCAN;
/*
测试类
 */
public class AnimalDemo {
    public static void main(String[] args) {
//        AnimalOperator ao = new AnimalOperator();
//        Animal a = new Cat();
//        ao.useAnimal(a);
        Integer i1= new Integer(100);
        System.out.println(i1);
        long start = System.currentTimeMillis();
        for (int i = 0;i<10000;i++){
            System.out.println(i);

        }
        long end = System.currentTimeMillis();
        System.out.println("共耗时："+(end-start)+"毫秒");
    }
}
