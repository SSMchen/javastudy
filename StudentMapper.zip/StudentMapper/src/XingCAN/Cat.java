package XingCAN;
/*
多态形式创建抽象类的子类对象，（在子类中重写抽象类中的方法）用来传递。//需要的是该类的子类对象
 */
public class Cat extends Animal{
    @Override
    public void eat() {
        System.out.println("猫吃鱼");
    }
}
