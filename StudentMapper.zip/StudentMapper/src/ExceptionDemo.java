/*
异常
 */
public class ExceptionDemo {
    public static void main(String[] args){
        //main 方法    在其中调用method方法
        method();
    }
    public static void method(){
        //定义一个int类型数组  通过数组以及索引1 访问元素值
        int[] arr = {1,2,3};
//        System.out.println(arr[1]);
 //       System.out.println(arr[3]);//ArrayIndexOutOfBoundsException 数组的索引越界异常
        System.out.println(arr[2]);
    }
}
