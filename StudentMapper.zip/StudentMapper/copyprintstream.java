package CopyFilter;

import java.io.FileNotFoundException;
import java.io.PrintStream;

public class PrintStreamDemo {
    public static void main(String[] args) throws FileNotFoundException {
        PrintStream ps = new PrintStream("ps.txt");
        //写数据
        //write字节输出流方法
//        ps.write(97);//a
        //使用特有方法写数据  Print /println
//        ps.print(97);//97
//        ps.println();
//        ps.print(98);
        ps.println(97);
        ps.println(98);

        //释放资源
        ps.close();
    }
}
